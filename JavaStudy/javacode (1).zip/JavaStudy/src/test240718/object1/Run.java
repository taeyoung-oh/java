package test240718.object1;

public class Run {

	public static void main(String[] args) {
		new PersonMenu().mainMenu();
	}

}

package test240718.object2;

public interface NotePen {
	boolean PEN_BUTTON = true;
	
	boolean bluetoothPen();
}

package test240718.object2;

public interface TouchDisplay {
	String touch();
}

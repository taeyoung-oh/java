package test240718.object2;

public interface CellPhone extends Phone, Camera{
	public String charge();
}

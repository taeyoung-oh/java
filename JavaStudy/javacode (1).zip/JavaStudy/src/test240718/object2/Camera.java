package test240718.object2;

public interface Camera {
	public abstract String picture();
}

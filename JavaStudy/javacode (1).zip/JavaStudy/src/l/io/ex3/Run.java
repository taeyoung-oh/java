package l.io.ex3;

public class Run {

	public static void main(String[] args) {
		
//		new FileByte().fileSave();
//		new FileByte().fileRead();
//		new FileChar().fileSave();
		new FileChar().fileRead();
	}

}

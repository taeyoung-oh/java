package a.basic;

public class LineComment {
	public static void main(String[] args) {
		System.out.println(100); // 단순한 정수 출력
		
		System.out.println("안녕하세요.");
		System.out.println("최지원입니다.");
		
		/*
		  인사말을 간단하게
		  출력해보자
		*/
		
		/*
		 * 주석 : 컴퓨터는 인식하지 않고 사람이 필요에 따라
		 *       설명등을 적어두는 용도로 사용한다.
		 */
	}
}

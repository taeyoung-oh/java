package m.api.ex1;

public class Run {

	public static void main(String[] args) {
//		new A_Math().method01();
//		new B_String().method01();
//		new B_String().method02();
//		new B_String().method03();
//		new C_Wrapper().method01();
		new D_Date().method01();
	}

}

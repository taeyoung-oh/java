package test240723.object1;

public class Run {

	public static void main(String[] args) {
		new CharacterMenu().menu();

	}

}

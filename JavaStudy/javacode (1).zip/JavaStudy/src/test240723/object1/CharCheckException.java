package test240723.object1;

public class CharCheckException extends RuntimeException{

	public CharCheckException() {
		super();
	}

	public CharCheckException(String message) {
		super(message);
	}
}

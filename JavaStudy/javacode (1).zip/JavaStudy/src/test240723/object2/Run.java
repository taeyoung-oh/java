package test240723.object2;

public class Run {

	public static void main(String[] args) {
		new NumberMenu().menu();

	}

}

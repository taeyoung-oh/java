package test240712.object1;

public class Run {

	public static void main(String[] args) {
		MemberMenu mm = new MemberMenu();
		mm.mainMenu();

	}

}

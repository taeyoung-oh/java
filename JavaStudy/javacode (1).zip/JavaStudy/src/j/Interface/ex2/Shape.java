package j.Interface.ex2;

public interface Shape {
	/*public abstract*/double calculateArea();
}

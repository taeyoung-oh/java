package j.Interface.ex1;


public interface Animal {
	//static변수
	//추상메소드 : 미완성 메소드로 구현부({})가 없는 메소드
	//abstract 추상키워드를 붙여서 생성
	public abstract void move();
	public abstract void eat();
	public abstract void makeSound();
}

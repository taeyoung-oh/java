package j.Interface.ex1;

public interface Baby {

}

package test240710.object4;

public class Run {

	public static void main(String[] args) {
		SnackMenu sm = new SnackMenu();
		sm.menu();

	}

}

package test240710.object1;

public class Run {
	public static void main(String[] args) {
		Person jiwon = new Person();
	}
}

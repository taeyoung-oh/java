package test240711.object3;

public class Run2 {

	public static void main(String[] args) {
		Library li = new Library();
		li.menu();
		
//		new Library().menu();

	}

}

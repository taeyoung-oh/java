package test240711.object4;

public class Run {

	public static void main(String[] args) {
		
		StudentMenu sm = new StudentMenu();
	}

}

package test240719.object2;

public interface Bonus {
	public void incentive(int pay);
}
